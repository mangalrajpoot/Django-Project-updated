from django.contrib import admin
from .models import Branch,Course,Enquirysource,DesignationMaster,Enquiry,Register,Fees,Recruit,AdminLogin

# Register your models here.
admin.site.register(Branch)
admin.site.register(Course)
admin.site.register(Enquirysource)
admin.site.register(DesignationMaster)
admin.site.register(Enquiry)
admin.site.register(Register)
admin.site.register(Fees)
admin.site.register(Recruit)
admin.site.register(AdminLogin)