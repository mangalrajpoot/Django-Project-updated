from django.db import models

# Model For Branch
class Branch(models.Model):
    branchname=models.CharField(max_length=100)

class Course(models.Model):
    coursename=models.CharField(max_length=100)

class Enquirysource(models.Model):
    sourcename=models.CharField(max_length=100)
    
class DesignationMaster(models.Model):
    designation=models.CharField(max_length=100)
    
    

class Enquiry(models.Model):
    fullname=models.CharField(max_length=100,unique=True)
    mobile=models.CharField(max_length=100)
    email=models.CharField(max_length=100,unique=True)
    dob=models.CharField(max_length=50)
    collegename=models.CharField(max_length=100)
    higherqualification=models.CharField(max_length=50)
    enqdate=models.CharField(max_length=50)
    coursename=models.CharField(max_length=50)
    enquirysource=models.CharField(max_length=50)
    branchid=models.ForeignKey(Branch,on_delete=models.CASCADE)
    staffid=models.CharField(max_length=100)
    
        
class Register(models.Model):
    coursename=models.CharField(max_length=100)
    regdate=models.CharField(max_length=50)
    totalfees=models.IntegerField()
    submittedfees=models.IntegerField()
    remainingfees=models.IntegerField()
    discount=models.IntegerField()
    enquiryid=models.ForeignKey(Enquiry,on_delete=models.CASCADE)
    
    
class Fees(models.Model):
    regid=models.ForeignKey(Register,on_delete=models.CASCADE)
    courseid=models.ForeignKey(Course,on_delete=models.CASCADE)
    installment=models.IntegerField()
    submittedamount=models.IntegerField()
    remainingfees=models.IntegerField()
    
    
class Recruit(models.Model):
    email=models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    staffname=models.CharField(max_length=50)
    joiningdate=models.CharField(max_length=50)
    designation=models.CharField(max_length=50)
    experience=models.CharField(max_length=50)
    
    
class AdminLogin(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    