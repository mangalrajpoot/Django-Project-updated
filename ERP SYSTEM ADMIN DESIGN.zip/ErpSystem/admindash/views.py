from django.shortcuts import render,redirect
from django.http import HttpResponse 
from .models import AdminLogin


# Create Views for Home Page View
def index(request):
    return render(request,"admindash/index.html")


#code for AdminLogin Page View

def adminLogin(request):
    if request.method=="POST":
        obj=AdminLogin.objects.filter(username=request.POST["username"],password=request.POST["password"])
        if(obj.count()>0):
            request.session["loginid"]=request.POST["username"]
            return redirect("dashboard") 
    return render(request,"admindash/adminLogin.html")        
        

def dashboard(request):
    if(request.session.has_key("loginid")):
        data=request.session["loginid"]
        return render(request,"admindash/dashboard.html",{"key":data})
    else:
        return render(request,"admindash/adminLogin.html")
    
def Logout(request):
    del request.session["loginid"]
    return redirect("adminLogin")