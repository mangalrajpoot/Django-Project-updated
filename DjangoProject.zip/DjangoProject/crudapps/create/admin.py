from django.contrib import admin
from .models import Employee
admin.site.register(Employee)

# Register your models here.
