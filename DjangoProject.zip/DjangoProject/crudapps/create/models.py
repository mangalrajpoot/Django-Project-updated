from django.db import models


class Employee(models.Model):
    empname = models.CharField(max_length=50)
    empdept = models.CharField(max_length=50)
    emppos = models.CharField(max_length=50)
    empsal = models.FloatField(max_length=20)


# Create your models here.
