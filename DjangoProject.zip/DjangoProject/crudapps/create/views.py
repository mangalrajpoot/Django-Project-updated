from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Employee

# Create your views here.


def create(request):
    if request.method == "POST":
        empname = request.POST['empname']
        empdept = request.POST['empdept']
        emppos = request.POST['emppos']
        empsal = request.POST['empsal']
        obj = Employee(empname=empname, empdept=empdept,
                       emppos=emppos, empsal=empsal)
        obj.save()
        return redirect("read")
        #return render(request, "create/insert.html", {"key": "Data Inserted Successfully !"})
    return render(request, "create/read.html")


def insert(request):
    if request.method == "POST":
        empname = request.POST['empname']
        empdept = request.POST['empdept']
        emppos = request.POST['emppos']
        empsal = request.POST['empsal']
        obj = Employee(empname=empname, empdept=empdept,
                       emppos=emppos, empsal=empsal)
        obj.save()
        #return redirect("insert")
        
        return render(request, "create/insert.html", {"key": "Data Inserted Successfully !"})
    return render(request, "create/insert.html")


def read(request):
    data = Employee.objects.all()
    return render(request, "create/read.html", {"res": data})


def update(request):
    data = Employee.objects.get(pk=request.GET['q'])
    if request.method == "POST":
        data.empname = request.POST["empname"]
        data.empdept = request.POST["empdept"]
        data.emppos = request.POST["emppos"]
        data.empsal = request.POST["empsal"]
        data.save()
        return redirect("read")
    return render(request, "create/update.html", {"res": data})

def delete(request):
    data=Employee.objects.get(pk=request.GET['q'])
    if request.method=="POST":
        data.delete()
        return redirect("read")
    return render(request,"create/deleteconfirmation.html",{"emp":data})

def login(request):
    if request.method=="POST":
        obj=Employee.objects.filter(empname=request.POST["empname"],empdept=request.POST["empdept"])
        if(obj.count()>0):
            return redirect("read")
        else:
            return render(request,"create/login.html",{"key":"Invalid Username & password !"})
    return render(request,"create/login.html")