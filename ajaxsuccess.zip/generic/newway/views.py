from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView 
from django.views.generic.edit import UpdateView 
from django.views.generic.edit import DeleteView 
from newway.views import CreateView,ListView,DetailView,UpdateView,DeleteView
from django.urls import reverse
from django.views import View
from . import views
from .models import Job,Employeeregister
from django.http import HttpResponse
from django.shortcuts import render
class JobCreate(CreateView):
    model=Job
    fields=['jobtitle','jobdescription']
    success_url="/"  
    
class JobList(ListView):
    model=Job #job.objects.all()
    
class JobDetail(DetailView):
    model=Job
    

class JobUpdate(UpdateView):
    model=Job #Job.objects.all()
    fields=["jobtitle","jobdescription"]
    success_url="/newway/joblist"
    
class JobDelete(DeleteView):
    model=Job 
    success_url="/newway/joblist" 
    
def ajaxload(request):
    return render(request,"newway/ajaxload.html")

def ajaxdata(request):
    data=request.GET["q"]
    res=Job.objects.filter(jobtitle__contains=data)
    return render(request,"newway/ajaxresult.html",{"key":res})

# def ajaxdata1(request):
#     data=request.GET["q"] 
#     res=Job.objects.get(pk=data)
#     res1=str(res.id)+' '+res.jobtitle+' '+res.jobdescription
#     return HttpResponse(res1)


def reg(request):
    return render(request,"newway/reg.html")

def regcode(request): 
    print("data is",request.POST.get("empname"))
    print(request.POST.get("emppost"))
    r=Employeeregister(empname=request.POST.get("empname"),empdept=request.POST.get("empdept"),emppost=request.POST.get("emppost"),empemail=request.POST.get("empemail"),emppass=request.POST.get("emppass"),empcpass=request.POST.get("empcpass"))
    r.save()
    return HttpResponse("data inserted successfully")

    

    
    
      
   