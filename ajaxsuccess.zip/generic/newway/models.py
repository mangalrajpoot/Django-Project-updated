from django.db import models
class Job(models.Model):
    jobtitle=models.CharField(max_length=50)
    jobdescription=models.CharField(max_length=50)
    
class Employeeregister(models.Model):
    empname=models.CharField(max_length=50)
    empdept=models.CharField(max_length=50)
    emppost=models.CharField(max_length=50)
    empemail=models.CharField(max_length=50)
    emppass=models.CharField(max_length=50)
    empcpass=models.CharField(max_length=50)
    