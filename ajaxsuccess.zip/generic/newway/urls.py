from newway.views import JobCreate,JobList,JobDetail,JobUpdate,JobDelete
from . import views
from django.urls import path

urlpatterns=[
    path('',JobCreate.as_view()),
    path("joblist",JobList.as_view()),
    #path("<pk>",JobDetail.as_view()),
    path("<pk>/jupdate",JobUpdate.as_view()),
    path("<pk>/jdelete",JobDelete.as_view()),
    path('reg',views.reg,name='reg'),
    path('regcode',views.regcode,name='regcode'),
    path("ajaxload",views.ajaxload,name="ajaxload"),
    path("ajaxdata",views.ajaxdata,name="ajaxdata"),
    #path('ajaxdata1',views.ajaxdata1,name='ajaxdata1')

]

