from django.contrib import admin
from .models import Job,Employeeregister
admin.site.register(Job)
admin.site.register(Employeeregister)

# Register your models here.
